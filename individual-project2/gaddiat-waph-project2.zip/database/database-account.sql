create database ip2;
create user 'a'@'localhost' IDENTIFIED BY '1234';
grant ALL on ip2.* TO 'a'@'localhost';